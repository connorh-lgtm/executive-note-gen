// Content script for LinkedIn Sales Navigator
console.log('Ghost Note extension loaded on Sales Navigator');

// Function to extract prospect data from Sales Nav profile page
function extractProspectData() {
  const data = {
    prospect_name: '',
    prospect_title: '',
    prospect_company: '',
    unique_fact: '',
    linkedin_url: window.location.href
  };

  try {
    console.log('Starting data extraction...');

    // Extract name - Sales Nav 2024/2025 layouts
    const nameSelectors = [
      // Sales Nav specific - near profile photo
      '.profile-topcard__name',
      '.profile-topcard-person-entity__name',
      'div.profile-topcard h1',
      'div[class*="profile-topcard"] h1',
      '.artdeco-entity-lockup__title',
      'h1.text-heading-xlarge',
      // More specific patterns
      'div.pv-top-card h1',
      'section[class*="profile"] h1'
    ];
    
    for (const selector of nameSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        const text = element.textContent.trim();
        // Filter out page titles and navigation text
        if (text && text.length > 2 && text.length < 100 && 
            !text.includes('Sales Navigator') && 
            !text.includes('Page') &&
            !text.includes('LinkedIn')) {
          data.prospect_name = text;
          console.log('Found name:', text, 'using selector:', selector);
          break;
        }
      }
      if (data.prospect_name) break;
    }
    
    // If still not found, try page title as last resort but clean it
    if (!data.prospect_name) {
      const titleMatch = document.title.match(/^([^|]+)/);
      if (titleMatch) {
        const name = titleMatch[1].trim();
        if (name && !name.includes('Sales Navigator') && !name.includes('LinkedIn')) {
          data.prospect_name = name;
          console.log('Found name from title:', name);
        }
      }
    }

    // Extract title - look for headline/title patterns
    // First try standard selectors
    const titleSelectors = [
      '.profile-topcard__headline',
      '.profile-topcard-person-entity__headline',
      'div.profile-topcard div.text-body-medium',
      'div[class*="profile-topcard"] div[class*="headline"]',
      '[data-anonymize="title"]',
      '.artdeco-entity-lockup__subtitle',
      'div.pv-top-card div.text-body-medium',
      // Try elements near the name
      'div.profile-topcard span.text-body-medium',
      'div[class*="profile"] span.text-body-medium'
    ];
    
    for (const selector of titleSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        const text = element.textContent.trim();
        // Filter out non-title text and buttons
        if (text && text.length > 5 && text.length < 200 && 
            !text.includes('Message') && 
            !text.includes('Connect') &&
            !text.includes('Follow') &&
            !text.includes('More') &&
            !text.includes('Sales Navigator') &&
            !text.toLowerCase().includes('button')) {
          data.prospect_title = text;
          console.log('Found title:', text, 'using selector:', selector);
          break;
        }
      }
      if (data.prospect_title) break;
    }
    
    // If title not found, try to find text BELOW/AFTER the name element
    if (!data.prospect_title && data.prospect_name) {
      console.log('Trying to find title below name element...');
      
      // Find the name element first
      const nameElement = Array.from(document.querySelectorAll('h1, div, span')).find(el => 
        el.textContent.trim() === data.prospect_name
      );
      
      if (nameElement) {
        // Look for next sibling or nearby elements
        let nextElement = nameElement.nextElementSibling;
        let attempts = 0;
        
        while (nextElement && attempts < 5) {
          const text = nextElement.textContent.trim();
          if (text && text.length > 5 && text.length < 200 && 
              text !== data.prospect_name &&
              !text.includes('Message') && 
              !text.includes('Connect') &&
              !text.includes('Follow') &&
              !text.includes('More')) {
            data.prospect_title = text;
            console.log('Found title below name:', text);
            break;
          }
          nextElement = nextElement.nextElementSibling;
          attempts++;
        }
        
        // If still not found, look in parent's next elements
        if (!data.prospect_title && nameElement.parentElement) {
          const parentNext = nameElement.parentElement.nextElementSibling;
          if (parentNext) {
            const text = parentNext.textContent.trim();
            if (text && text.length > 5 && text.length < 200 && 
                !text.includes('Message') && !text.includes('Connect')) {
              data.prospect_title = text;
              console.log('Found title in parent next:', text);
            }
          }
        }
      }
    }

    // Extract company - look for company mentions
    const companySelectors = [
      '.profile-topcard__company-name',
      '[data-anonymize="company-name"]',
      'button[aria-label*="Current company"]',
      'a[data-control-name*="company"]',
      '.artdeco-entity-lockup__caption'
    ];
    
    for (const selector of companySelectors) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        const text = element.textContent.trim();
        if (text && text.length > 1 && text.length < 150) {
          data.prospect_company = text;
          console.log('Found company:', text);
          break;
        }
      }
      if (data.prospect_company) break;
    }

    // Fallback: Try to extract from page text if specific selectors fail
    if (!data.prospect_name || !data.prospect_company) {
      console.log('Using fallback extraction...');
      
      // Try to get name from page title
      if (!data.prospect_name) {
        const titleMatch = document.title.match(/^([^|]+)/);
        if (titleMatch) {
          const name = titleMatch[1].trim();
          if (name && name.length > 2 && name.length < 100) {
            data.prospect_name = name;
            console.log('Found name from title:', name);
          }
        }
      }
      
      // Try to find company in visible text
      if (!data.prospect_company) {
        const bodyText = document.body.innerText;
        const companyMatch = bodyText.match(/at\s+([A-Z][A-Za-z\s&,.-]+?)(?:\s*\||$)/);
        if (companyMatch && companyMatch[1]) {
          data.prospect_company = companyMatch[1].trim();
          console.log('Found company from text:', data.prospect_company);
        }
      }
    }

    // Extract summary/about for unique facts
    const summarySelectors = [
      '.profile-topcard__summary',
      '[data-test-id="about-section"]',
      '.pv-about-section',
      '.inline-show-more-text'
    ];
    
    for (const selector of summarySelectors) {
      const summaryElement = document.querySelector(selector);
      if (summaryElement && summaryElement.textContent.trim()) {
        const summary = summaryElement.textContent.trim();
        data.unique_fact = summary.substring(0, 300) + (summary.length > 300 ? '...' : '');
        console.log('Found summary');
        break;
      }
    }

    console.log('Extraction complete:', data);

  } catch (error) {
    console.error('Error extracting prospect data:', error);
  }

  return data;
}

// Create floating button
function createFloatingButton() {
  // Check if button already exists
  if (document.getElementById('ghost-note-button')) {
    return;
  }

  const button = document.createElement('button');
  button.id = 'ghost-note-button';
  button.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
    </svg>
    <span>Send to Ghost Note</span>
  `;
  
  button.style.cssText = `
    position: fixed;
    bottom: 30px;
    right: 30px;
    z-index: 9999;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 50px;
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;

  button.addEventListener('mouseenter', () => {
    button.style.transform = 'translateY(-2px)';
    button.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.5)';
  });

  button.addEventListener('mouseleave', () => {
    button.style.transform = 'translateY(0)';
    button.style.boxShadow = '0 4px 15px rgba(102, 126, 234, 0.4)';
  });

  button.addEventListener('click', async () => {
    button.disabled = true;
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 6v6l4 2"/>
      </svg>
      <span>Sending...</span>
    `;

    const data = extractProspectData();
    
    // Validate data
    if (!data.prospect_name || !data.prospect_company) {
      alert('Could not extract prospect data. Please make sure you are on a Sales Navigator profile page.');
      button.disabled = false;
      button.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
        </svg>
        <span>Send to Ghost Note</span>
      `;
      return;
    }

    // Get Ghost Note URL from storage
    chrome.storage.sync.get(['ghostNoteUrl'], (result) => {
      const baseUrl = result.ghostNoteUrl || 'http://localhost:8000';
      
      // Build URL with query parameters
      const params = new URLSearchParams({
        prospect_name: data.prospect_name,
        prospect_title: data.prospect_title || '',
        prospect_company: data.prospect_company,
        unique_fact: data.unique_fact || '',
        linkedin_url: data.linkedin_url
      });

      const url = `${baseUrl}?${params.toString()}`;
      
      // Open Ghost Note in new tab
      window.open(url, '_blank');

      // Reset button
      setTimeout(() => {
        button.disabled = false;
        button.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M5 13l4 4L19 7"/>
          </svg>
          <span>Sent!</span>
        `;
        
        setTimeout(() => {
          button.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
            <span>Send to Ghost Note</span>
          `;
        }, 2000);
      }, 500);
    });
  });

  document.body.appendChild(button);
}

// Initialize when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', createFloatingButton);
} else {
  createFloatingButton();
}

// Re-create button on navigation (Sales Nav is a SPA)
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    setTimeout(createFloatingButton, 1000);
  }
}).observe(document, { subtree: true, childList: true });
